import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Weather from "./components/Weather";

function App() {
  return (
    <>
      <h1>Weather App</h1>
      <Weather />
    </>
  );
}

export default App;
