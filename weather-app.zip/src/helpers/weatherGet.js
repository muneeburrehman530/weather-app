// import axios from "axios";

//  export const ApiKey = "a4930c4eb27b860faabb309ab309e10f"; 
// export const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${APIkey}`
// export const weatherApi = axios.create({
//     baseURL : apiUrl,
//     params: {
//         appid: "api key",
//         units: "metric"
//     }
// });

// // Get weather data

// const getWeather = async () => {

// try {
//     const response = await weatherApi.get('', {
//         params: {q: city },

//     });
//     console.log(response.data, "kia hai weahter")
//     return response.data; 

// } catch (error) {
//     console.log(err, "weather app war gai");
//     throw error;
// }

   
// }

// export default {getWeather};